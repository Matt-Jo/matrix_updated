BODY {
	margin:		1em;
}
#header {
}
#nav {
	display:	none;
}
#packagePosition {
	text-align:	right;
}
#packageTitle {
	display:	inline;
	margin:		5px;
}
#packageTitle2 {
	display:	none;
}
#elementPath {
	display:	inline;
	margin:		5px;
}
#navLinks {
	display:	none;
}
